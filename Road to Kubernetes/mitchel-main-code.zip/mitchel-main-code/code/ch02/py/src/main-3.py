import pathlib

from fastapi import FastAPI, Request  # <1>
from fastapi.responses import HTMLResponse  # <2>
from fastapi.templating import Jinja2Templates  # <3>

BASE_DIR = pathlib.Path(__file__).parent # <1>
TEMPLATES_DIR = BASE_DIR / "templates" # <2>
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

app = FastAPI()

@app.get("/", response_class=HTMLResponse) #<1>
def read_index(request: Request): # <2>
    context = {"request": request} # <3>
    return templates.TemplateResponse("home.html", context) # <4>
