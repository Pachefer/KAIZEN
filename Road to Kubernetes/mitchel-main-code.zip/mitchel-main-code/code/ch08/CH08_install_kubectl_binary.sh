# if x86, use amd64
export PLATFORM="amd64" 

# if ARM, use arm64 and
# uncomment the following line
# export PLATFORM="arm64"

# get latest release version
export VER=$(curl -L -s https://dl.k8s.io/release/stable.txt)

# download latest release
curl -LO "https://dl.k8s.io/release/$VER/bin/linux/$PLATFORM/kubectl"

# verify the release
curl -LO "https://dl.k8s.io/$VER/bin/linux/$PLATFORM/kubectl.sha256"
echo "$(cat kubectl.sha256)  kubectl" | sha256sum --check

# install kubectl
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# verify installation
kubectl version --client --output=yaml