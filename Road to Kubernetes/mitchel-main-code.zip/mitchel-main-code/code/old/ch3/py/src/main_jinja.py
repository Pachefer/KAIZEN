import pathlib

from fastapi import FastAPI, Request  # <2>
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates  # <3>

BASE_DIR = pathlib.Path(__file__).parent # <4>
TEMPLATES_DIR = BASE_DIR / "templates" # <5>
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def read_index(request: Request): # <8>
    context = {"request": request} # <9>
    return templates.TemplateResponse("home.html", context) # <10>
