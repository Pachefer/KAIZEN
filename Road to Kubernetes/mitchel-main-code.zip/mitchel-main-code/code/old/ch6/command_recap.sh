# update the apt package list
sudo apt update

# install apt packages
sudo apt install -y \
    git \
    supervisor \
    nginx \
    ufw \
    nodejs \
    python3 \
    python3-pip \
    python3-venv \
    build-essential \
    curl

# install nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.2/install.sh | bash

# create virtual environment
python3 -m venv /home/ubuntu/venv

# install Node.js v 18.12.1 LTS
nvm install 18.12.1
source ~/.bashrc

# configure ufw
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable