
const express = require('express')
const path = require('node:path')
const app = express()
const port = process.env.PORT || 3000

const BASE_DIR = path.resolve(__dirname);
const TEMPLATE_DIR = path.join(BASE_DIR, "templates")

app.set('view engine', 'pug')
app.set('views', TEMPLATE_DIR)

let globalCount = 0
const updateGlobalCount = async () => {
    setTimeout(()=>{
        globalCount++
        console.log(`working on ${globalCount}`)
    }, 5000)
}

app.get('/', async (req, res) => {
    await updateGlobalCount()
    await res.render("home.pug", {title: `Hi Justin ${globalCount}`})

})

app.listen(port, () => { // <6>
    console.log(`Server running on port http://127.0.0.1:${port}`) // <7>
  })