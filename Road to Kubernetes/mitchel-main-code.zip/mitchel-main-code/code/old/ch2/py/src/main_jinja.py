import pathlib # <1>
from fastapi import FastAPI, Request # <1>
from fastapi.responses import HTMLResponse 
from fastapi.templating import Jinja2Templates # <1>

BASE_DIR = pathlib.Path(__file__).parent # <2>
TEMPLATES_DIR = BASE_DIR / "templates" # <3>

templates = Jinja2Templates(directory=str(TEMPLATES_DIR)) # <2>

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def read_index(request: Request): # <2>
    context = {"request": request} # <3>
    return templates.TemplateResponse("home.html", context) # <4>

@app.get("/", response_class=HTMLResponse)
def read_index(request: Request):
    context = {"request": request, "my_var": "Justin"} # <1>
    return templates.TemplateResponse("home.html", context)