from fastapi import FastAPI
from fastapi.responses import HTMLResponse # <1>

app = FastAPI()

@app.get("/", response_class=HTMLResponse) # <2>
def read_index():
    return """ # <3>
    <!doctype html>
    <html>
        <head>
            <title>Hello World</title>
        </head>
        <body>
            <h1>Hello World</h1>
        </body>
    </html>
    """