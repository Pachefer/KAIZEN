const express = require('express') // <1>
const app = express() // <2>
const port = process.env.PORT || 3000 // <3>

app.get('/', (req, res) => { // <4>
    res.send("<h1>Hello Express World!</h1>") // <5>
})

app.listen(port, () => { // <6>
  console.log(`Server running on port http://127.0.0.1:${port}`) // <7>
})