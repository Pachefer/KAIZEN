sudo ln -s /etc/nginx/sites-available/roadtok8s \
    /etc/nginx/sites-enabled/roadtok8s