export NVM_VERSION="v0.39.3" <1>
curl -o- \
    https://raw.githubusercontent.com/nvm-sh/nvm/$NVM_VERSION/install.sh \
    | bash