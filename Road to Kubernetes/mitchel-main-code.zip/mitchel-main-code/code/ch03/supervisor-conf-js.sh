export NODE_PATH=$(which node) <1>
cat << EOF > /etc/supervisor/conf.d/roadtok8s-js.conf
[program:roadtok8s-js]
directory=/opt/projects/roadtok8s/js/src
command=$NODE_PATH main.js
autostart=true
autorestart=true
startretries=3
stderr_logfile=/var/log/supervisor/roadtok8s/js/stderr.log
stdout_logfile=/var/log/supervisor/roadtok8s/js/stdout.log
EOF