export APP_CMD="/opt/venv/bin/gunicorn \
    --worker-class uvicorn.workers.UvicornWorker \
    main:app --bind "0.0.0.0:8888" \
    --pid /var/run/roadtok8s-py.pid"
cat << EOF > /etc/supervisor/conf.d/roadtok8s-py.conf
[program:roadtok8s-py]
directory=/opt/projects/roadtok8s/py/src
command=$APP_CMD
autostart=true
autorestart=true
startretries=3
stderr_logfile=/var/log/supervisor/roadtok8s/py/stderr.log
stdout_logfile=/var/log/supervisor/roadtok8s/py/stdout.log
EOF