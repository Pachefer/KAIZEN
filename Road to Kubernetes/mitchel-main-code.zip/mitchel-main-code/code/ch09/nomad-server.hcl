# Located at /etc/nomad.d/nomad.hcl
data_dir = "/opt/nomad/data"

bind_addr = "0.0.0.0"

name = "nomad-server-1"

advertise {
    http = "192.168.204.96"
    rpc = "192.168.204.96"
    serf = "192.168.204.96"
}

server {
    enabled = true
    bootstrap_expect = 1 # number of servers
}

client {
    enabled = false
}