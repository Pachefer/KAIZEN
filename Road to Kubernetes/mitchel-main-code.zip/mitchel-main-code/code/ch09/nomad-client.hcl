# Located at /etc/nomad.d/nomad.hcl

data_dir = "/opt/nomad/data"

bind_addr = "0.0.0.0"

name = "nomad-client"

server {
    enabled = false
}

client {
    enabled = true
    options = {
        "driver.raw_exec.enable" = "1"
        "docker.privileged.enabled" = "true"
    }
    servers = ["192.168.204.96:4647"]
    server_join {
        retry_join = ["192.168.204.96:4647"]
    }
}


ui {
    enabled = false
}